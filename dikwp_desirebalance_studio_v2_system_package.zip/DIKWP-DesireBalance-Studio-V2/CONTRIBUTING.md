# Contributing

Contributions are welcome when they preserve the following constraints:

1. Synthetic or properly consented data only.
2. No punitive individual ranking, eligibility denial, or hidden profiling.
3. New metrics must declare assumptions, uncertainty, counterexamples, and failure conditions.
4. Every high-impact recommendation must retain human review, appeal, exit, and rollback.
5. Preserve DIKWP / Yucong Duan attribution in `NOTICE` and `CITATION.cff`.
6. Do not add network calls, telemetry, browser automation, credentials, or production decision connectors to the offline core.

Please include tests and update the relevant documentation.
