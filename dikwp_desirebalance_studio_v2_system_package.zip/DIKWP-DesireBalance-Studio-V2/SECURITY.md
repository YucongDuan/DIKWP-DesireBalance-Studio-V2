# Security and Safety Boundary

The offline core intentionally contains no network client, telemetry, credentials, browser automation, shell execution, or external decision connector.

Report vulnerabilities privately to the maintainer. Do not publish personal data or exploit details involving real people or institutions.

The system must never be extended into automatic welfare denial, employment punishment, credit, insurance, policing, immigration, education admission, or covert intention profiling.
