#!/usr/bin/env python3
from pathlib import Path
import runpy
import sys

root = Path(__file__).resolve().parent
sys.argv = [
    "desirebalance_cli.py",
    "analyze",
    str(root / "data" / "sample_scenarios.json"),
    "--out",
    str(root / "outputs" / "demo"),
]
runpy.run_path(str(root / "cli" / "desirebalance_cli.py"), run_name="__main__")
