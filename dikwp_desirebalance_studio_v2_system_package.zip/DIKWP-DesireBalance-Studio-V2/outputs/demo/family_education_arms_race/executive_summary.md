# 家庭：教育军备竞赛与儿童发展

- System: DIKWP DesireBalance Studio V2 2.0.0
- Scenario: `family_education_arms_race`
- Role: `household`
- Decision: `structural_redesign_required`
- Semantic closure: **S1 Fragile Closure** (0.493)

## Core metrics

- Desire Quality Index: 0.510
- Prosperity Contribution Index: 0.456
- Involution Pressure Index: 0.790
- Capture Risk Index: 0.557
- Capability Conversion Efficiency: 0.358
- Time Sovereignty Index: 0.389
- Desire-Prosperity Balance Index: 0.420

## Action tickets

### DBV2-001 · Scale productive desire: 家庭阅读与科学探索计划
- Priority: medium
- Owner: household_joint_review
- Action: Run a reversible expansion pilot tied to capability, wellbeing, and evidence metrics.
- Rollback: Return to current scale if externalities, debt, or time burden exceed thresholds.

### DBV2-002 · Cooling and sufficiency redesign: 高强度竞赛与多科补习
- Priority: high
- Owner: household_joint_review
- Action: Add a cooling interval, cost disclosure, sufficiency threshold, and lower-cost substitute path.
- Rollback: Suspend the commitment and restore the previous budget/time allocation.

### DBV2-003 · Cooling and sufficiency redesign: 超预算购买学区房
- Priority: high
- Owner: household_joint_review
- Action: Add a cooling interval, cost disclosure, sufficiency threshold, and lower-cost substitute path.
- Rollback: Suspend the commitment and restore the previous budget/time allocation.

## Residuals

- Weights are configurable local policy parameters, not universal moral constants.
- Self-reported desires may differ from longitudinal behaviour and structural constraints.
- Distributional, labour, family, health, and ecological outcomes require external evaluation.
- The system cannot determine a person's worth, eligibility, employment, credit, welfare, or punishment.

## Action boundary

Deliberation, education, workshop, voluntary self-reflection, organizational redesign, and reversible policy-pilot use only.
