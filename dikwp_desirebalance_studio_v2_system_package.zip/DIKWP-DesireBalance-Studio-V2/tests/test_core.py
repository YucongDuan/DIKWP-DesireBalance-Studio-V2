from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("desirebalance_cli", ROOT / "cli" / "desirebalance_cli.py")
MOD = importlib.util.module_from_spec(SPEC)
sys.modules["desirebalance_cli"] = MOD
assert SPEC.loader is not None
SPEC.loader.exec_module(MOD)


def load_collection():
    return json.loads((ROOT / "data" / "sample_scenarios.json").read_text(encoding="utf-8"))


def test_organization_scenario_has_structural_signal():
    data = load_collection()
    sc = next(x for x in data["scenarios"] if x["scenario_id"] == "organization_kpi_involution")
    report = MOD.analyze_scenario(sc)
    assert report["summary"]["mean_involution_pressure_index"] > 0.6
    assert report["summary"]["semantic_closure_score"] > 0.4
    assert len(report["action_tickets"]) == len(sc["desire_items"])


def test_platform_dark_pattern_is_not_auto_supported():
    data = load_collection()
    sc = next(x for x in data["scenarios"] if x["scenario_id"] == "platform_intention_capture")
    report = MOD.analyze_scenario(sc)
    dark = next(x for x in report["desire_scores"] if x["desire_id"] == "plat_darkpattern")
    assert dark["capture_risk_index"] > 0.7
    assert dark["route"] in {"cool_and_reframe", "human_or_policy_review"}


def test_policy_simulation_improves_balance_or_time():
    data = load_collection()
    sc = next(x for x in data["scenarios"] if x["scenario_id"] == "policy_prosperity_anti_involution")
    report = MOD.analyze_scenario(sc)
    sim = report["default_policy_simulation"]
    assert sim["projected_time_sovereignty_index"] >= report["summary"]["mean_time_sovereignty_index"]
    assert sim["projected_involution_pressure_index"] <= report["summary"]["mean_involution_pressure_index"]


def test_static_audit_core_passes():
    result = MOD.static_audit(ROOT / "cli")
    assert result["pass"], result
