#!/usr/bin/env python3
"""DIKWP DesireBalance Studio V2 offline CLI.

Standard-library-only reference implementation for analysing synthetic or user-supplied
DesireBalance scenarios. It is a deliberation aid, not a moral ranking, eligibility,
employment, credit, welfare, clinical, or punitive decision system.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
from collections import Counter
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any, Iterable

VERSION = "2.0.0"
SYSTEM_NAME = "DIKWP DesireBalance Studio V2"

POSITIVE_WEIGHTS = {
    "autonomy": 0.16,
    "basic_need_relevance": 0.14,
    "capability_gain": 0.16,
    "relational_gain": 0.10,
    "innovation_spillover": 0.10,
    "wellbeing_durability": 0.14,
    "reversibility": 0.10,
    "evidence_strength": 0.10,
}
NEGATIVE_WEIGHTS = {
    "positionality": 0.19,
    "manipulation_pressure": 0.18,
    "debt_burden": 0.16,
    "time_burden": 0.14,
    "ecological_externality": 0.15,
    "third_party_externality": 0.18,
}
INVOLUTION_WEIGHTS = {
    "relative_rank_dependence": 0.16,
    "winner_take_all": 0.13,
    "effort_escalation": 0.16,
    "marginal_return_decline": 0.14,
    "forced_visibility": 0.09,
    "rule_opacity": 0.09,
    "exit_barrier": 0.10,
    "duplicated_effort": 0.07,
    "price_war_pressure": 0.04,
    "safety_externality": 0.02,
}

ROLE_ACTIONS = {
    "individual": [
        "Separate basic needs, capability goals, relational goals, and positional competition.",
        "Add a cooling interval and a sufficiency threshold to high-capture desires.",
        "Measure debt, time, attention, recovery, and relationship cost together with price.",
    ],
    "household": [
        "Protect a care-time and resilience floor before status-oriented spending.",
        "Replace single-rank education targets with a portfolio of capability and wellbeing goals.",
        "Make debt, comparison pressure, and unpaid care work visible in family decisions.",
    ],
    "organization": [
        "Replace forced ranking, overtime visibility, and tool-usage KPIs with quality, safety, reuse, and customer value.",
        "Publish workload recovery, appeal, role-transition, and exit mechanisms.",
        "Reward reusable knowledge and cooperation instead of repeated internal tournaments.",
    ],
    "platform": [
        "Audit urgency, infinite-scroll, shame, scarcity, hidden retention, and inferred-intent resale mechanisms.",
        "Offer intent reset, easy opt-out, transparent sponsorship, and revocable consent.",
        "Measure long-term trust, refunds, complaints, and cancellation success instead of conversion alone.",
    ],
    "community": [
        "Expand health, education, culture, sport, care, and small-business capability services.",
        "Use capability vouchers and public access infrastructure instead of coercive consumption targets.",
        "Track cost bearers, distributional effects, and exit routes for failed projects.",
    ],
    "policy": [
        "Coordinate consumption support with wage growth, social protection, public services, and supply quality.",
        "Treat destructive price wars, forced overtime, qualification inflation, and monopoly entry gates as system design problems.",
        "Require evidence, distributional analysis, sunset clauses, appeal, and reversible pilots.",
    ],
}

INTERVENTIONS = {
    "social_protection": {"capture": -0.08, "involution": -0.08, "prosperity": 0.05, "time": 0.02},
    "public_services": {"capture": -0.05, "involution": -0.06, "prosperity": 0.08, "time": 0.06},
    "kpi_reform": {"capture": -0.08, "involution": -0.16, "prosperity": 0.07, "time": 0.10},
    "anti_dark_pattern": {"capture": -0.18, "involution": -0.05, "prosperity": 0.02, "time": 0.03},
    "exit_rights": {"capture": -0.06, "involution": -0.12, "prosperity": 0.03, "time": 0.09},
    "capability_vouchers": {"capture": -0.04, "involution": -0.04, "prosperity": 0.12, "time": 0.04},
}


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def mean(values: Iterable[float]) -> float:
    values = list(values)
    return sum(values) / len(values) if values else 0.0


@dataclass
class DesireItem:
    desire_id: str
    actor_id: str
    actor_type: str
    name: str
    description: str
    category: str
    intensity: float = 0.5
    autonomy: float = 0.5
    basic_need_relevance: float = 0.0
    capability_gain: float = 0.5
    relational_gain: float = 0.3
    innovation_spillover: float = 0.3
    wellbeing_durability: float = 0.4
    reversibility: float = 0.5
    evidence_strength: float = 0.5
    positionality: float = 0.3
    manipulation_pressure: float = 0.2
    debt_burden: float = 0.2
    time_burden: float = 0.2
    ecological_externality: float = 0.2
    third_party_externality: float = 0.2
    evidence_refs: list[str] | None = None
    three_no_signals: list[str] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DesireItem":
        valid = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in valid})


@dataclass
class CompetitionContext:
    context_id: str
    name: str
    actor_type: str
    relative_rank_dependence: float = 0.5
    winner_take_all: float = 0.4
    effort_escalation: float = 0.5
    marginal_return_decline: float = 0.4
    forced_visibility: float = 0.3
    rule_opacity: float = 0.3
    exit_barrier: float = 0.4
    duplicated_effort: float = 0.4
    price_war_pressure: float = 0.3
    safety_externality: float = 0.2

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CompetitionContext":
        valid = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in valid})


def weighted(obj: object, weights: dict[str, float]) -> float:
    return sum(clamp(getattr(obj, key, 0.0)) * weight for key, weight in weights.items())


def score_desire(item: DesireItem) -> dict[str, Any]:
    positive = weighted(item, POSITIVE_WEIGHTS)
    burden = weighted(item, NEGATIVE_WEIGHTS)
    quality = clamp(0.55 + positive * 0.75 - burden * 0.85)
    prosperity = clamp(
        0.12
        + 0.20 * item.basic_need_relevance
        + 0.24 * item.capability_gain
        + 0.18 * item.innovation_spillover
        + 0.15 * item.relational_gain
        + 0.14 * item.wellbeing_durability
        - 0.12 * item.ecological_externality
        - 0.11 * item.third_party_externality
    )
    capture = clamp(
        0.34 * item.positionality
        + 0.32 * item.manipulation_pressure
        + 0.17 * item.debt_burden
        + 0.10 * item.time_burden
        + 0.07 * (1.0 - item.autonomy)
    )
    capability_conversion = clamp(
        0.34 * item.capability_gain
        + 0.22 * item.wellbeing_durability
        + 0.18 * item.innovation_spillover
        + 0.14 * item.autonomy
        + 0.12 * item.relational_gain
        - 0.10 * item.time_burden
        - 0.08 * item.debt_burden
    )
    time_sovereignty = clamp(
        1.0 - (0.46 * item.time_burden + 0.24 * item.manipulation_pressure + 0.18 * item.debt_burden + 0.12 * item.positionality)
    )
    purpose_coherence = clamp(
        0.26 * item.autonomy
        + 0.22 * item.capability_gain
        + 0.20 * item.wellbeing_durability
        + 0.16 * item.reversibility
        + 0.16 * item.evidence_strength
        - 0.14 * item.manipulation_pressure
        - 0.12 * item.third_party_externality
    )
    sufficiency_gap = clamp(1.0 - max(item.basic_need_relevance, item.wellbeing_durability))

    if item.basic_need_relevance >= 0.75 and burden <= 0.55:
        route = "protect_and_expand_basic_capability"
    elif quality >= 0.68 and prosperity >= 0.60 and capture < 0.45:
        route = "support_and_expand"
    elif capture >= 0.72 or (item.debt_burden >= 0.75 and item.positionality >= 0.55):
        route = "cool_and_reframe"
    elif item.third_party_externality >= 0.80 or item.manipulation_pressure >= 0.90:
        route = "human_or_policy_review"
    else:
        route = "redesign_and_pilot"

    incomplete = 1 if item.evidence_strength < 0.45 or not item.evidence_refs else 0
    imprecise = 1 if any(0.45 <= x <= 0.55 for x in [item.capability_gain, item.wellbeing_durability, item.evidence_strength]) else 0
    inconsistent = 1 if item.three_no_signals and any("不一致" in x or "冲突" in x for x in item.three_no_signals) else 0
    stability = clamp(1.0 - 0.22 * incomplete - 0.14 * imprecise - 0.22 * inconsistent + 0.10 * item.evidence_strength)

    return {
        "desire_id": item.desire_id,
        "actor_id": item.actor_id,
        "actor_type": item.actor_type,
        "name": item.name,
        "category": item.category,
        "desire_quality_index": round(quality, 4),
        "prosperity_contribution_index": round(prosperity, 4),
        "capture_risk_index": round(capture, 4),
        "capability_conversion_efficiency": round(capability_conversion, 4),
        "time_sovereignty_index": round(time_sovereignty, 4),
        "purpose_coherence_score": round(purpose_coherence, 4),
        "sufficiency_gap_proxy": round(sufficiency_gap, 4),
        "semantic_stability_score": round(stability, 4),
        "three_no": {"incomplete": bool(incomplete), "imprecise": bool(imprecise), "inconsistent": bool(inconsistent)},
        "route": route,
    }


def score_involution(context: CompetitionContext) -> dict[str, Any]:
    score = weighted(context, INVOLUTION_WEIGHTS)
    if score >= 0.72:
        grade = "I4 Severe Involution Pressure"
    elif score >= 0.56:
        grade = "I3 High Involution Pressure"
    elif score >= 0.40:
        grade = "I2 Material Involution Pressure"
    elif score >= 0.24:
        grade = "I1 Emerging Involution Pressure"
    else:
        grade = "I0 Low Involution Pressure"
    time_sovereignty = clamp(1.0 - (0.35 * context.exit_barrier + 0.28 * context.forced_visibility + 0.22 * context.effort_escalation + 0.15 * context.rule_opacity))
    return {
        "context_id": context.context_id,
        "name": context.name,
        "actor_type": context.actor_type,
        "involution_pressure_index": round(score, 4),
        "time_sovereignty_index": round(time_sovereignty, 4),
        "grade": grade,
    }


def stability_grade(score: float) -> str:
    if score >= 0.84:
        return "S4 Stable Closure"
    if score >= 0.68:
        return "S3 Supported Closure"
    if score >= 0.50:
        return "S2 Provisional Closure"
    if score >= 0.30:
        return "S1 Fragile Closure"
    return "S0 Blocked Closure"


def action_ticket(item: DesireItem, score: dict[str, Any], index: int) -> dict[str, Any]:
    route = score["route"]
    mapping = {
        "protect_and_expand_basic_capability": (
            "Protect capability floor",
            "high",
            "Expand access while checking distributional effects and delivery capacity.",
            "Pause expansion and return to the pre-pilot allocation if access becomes exclusionary.",
        ),
        "support_and_expand": (
            "Scale productive desire",
            "medium",
            "Run a reversible expansion pilot tied to capability, wellbeing, and evidence metrics.",
            "Return to current scale if externalities, debt, or time burden exceed thresholds.",
        ),
        "cool_and_reframe": (
            "Cooling and sufficiency redesign",
            "high",
            "Add a cooling interval, cost disclosure, sufficiency threshold, and lower-cost substitute path.",
            "Suspend the commitment and restore the previous budget/time allocation.",
        ),
        "human_or_policy_review": (
            "Human or policy review",
            "critical",
            "Block automatic action; require affected-stakeholder and policy review.",
            "Keep the prior state and preserve all evidence and appeal records.",
        ),
        "redesign_and_pilot": (
            "Redesign and reversible pilot",
            "medium",
            "Clarify the purpose, collect missing evidence, and run a small reversible pilot.",
            "Stop the pilot and restore the baseline if the claimed capability gain does not appear.",
        ),
    }
    title, priority, action, rollback = mapping[route]
    owner_map = {
        "individual": "individual_and_supporter",
        "household": "household_joint_review",
        "organization": "management_and_worker_representative",
        "platform": "product_governance_and_user_representative",
        "community": "community_steward_and_service_provider",
        "policy": "policy_owner_and_public_review",
    }
    return {
        "ticket_id": f"DBV2-{index:03d}",
        "desire_id": item.desire_id,
        "title": f"{title}: {item.name}",
        "priority": priority,
        "owner": owner_map.get(item.actor_type, "human_reviewer"),
        "route": route,
        "action": action,
        "evidence_refs": item.evidence_refs or [],
        "rollback_plan": rollback,
        "kill_conditions": [
            "Evidence custody is removed or fabricated.",
            "The analysis is used for punitive social ranking or automatic eligibility decisions.",
            "Affected people lose consent, appeal, exit, or human review rights.",
        ],
    }


def simulate_interventions(summary: dict[str, float], interventions: dict[str, float]) -> dict[str, Any]:
    capture = summary["mean_capture_risk_index"]
    involution = summary["mean_involution_pressure_index"]
    prosperity = summary["mean_prosperity_contribution_index"]
    time_index = summary["mean_time_sovereignty_index"]
    details = []
    for name, intensity in interventions.items():
        intensity = clamp(intensity)
        effect = INTERVENTIONS.get(name)
        if not effect:
            continue
        capture += effect["capture"] * intensity
        involution += effect["involution"] * intensity
        prosperity += effect["prosperity"] * intensity
        time_index += effect["time"] * intensity
        details.append({"intervention": name, "intensity": intensity, "effect": effect})
    capture, involution, prosperity, time_index = map(clamp, [capture, involution, prosperity, time_index])
    balance = clamp(0.34 * prosperity + 0.24 * summary["mean_desire_quality_index"] + 0.22 * (1 - involution) + 0.20 * (1 - capture))
    return {
        "projected_capture_risk_index": round(capture, 4),
        "projected_involution_pressure_index": round(involution, 4),
        "projected_prosperity_contribution_index": round(prosperity, 4),
        "projected_time_sovereignty_index": round(time_index, 4),
        "projected_balance_index": round(balance, 4),
        "interventions": details,
        "boundary": "Projection only. Local calibration and human review are required before any policy or organizational action.",
    }


def analyze_scenario(scenario: dict[str, Any]) -> dict[str, Any]:
    desires = [DesireItem.from_dict(x) for x in scenario.get("desire_items", [])]
    contexts = [CompetitionContext.from_dict(x) for x in scenario.get("competition_contexts", [])]
    desire_scores = [score_desire(x) for x in desires]
    involution_scores = [score_involution(x) for x in contexts]

    summary = {
        "desire_count": len(desires),
        "competition_context_count": len(contexts),
        "mean_desire_quality_index": round(mean(x["desire_quality_index"] for x in desire_scores), 4),
        "mean_prosperity_contribution_index": round(mean(x["prosperity_contribution_index"] for x in desire_scores), 4),
        "mean_capture_risk_index": round(mean(x["capture_risk_index"] for x in desire_scores), 4),
        "mean_capability_conversion_efficiency": round(mean(x["capability_conversion_efficiency"] for x in desire_scores), 4),
        "mean_time_sovereignty_index": round(mean([x["time_sovereignty_index"] for x in desire_scores] + [x["time_sovereignty_index"] for x in involution_scores]), 4),
        "mean_purpose_coherence_score": round(mean(x["purpose_coherence_score"] for x in desire_scores), 4),
        "mean_involution_pressure_index": round(mean(x["involution_pressure_index"] for x in involution_scores), 4),
        "route_counts": dict(Counter(x["route"] for x in desire_scores)),
    }
    closure_score = clamp(
        0.26 * mean(x["semantic_stability_score"] for x in desire_scores)
        + 0.22 * summary["mean_purpose_coherence_score"]
        + 0.18 * mean(x.evidence_strength for x in desires)
        + 0.18 * (1 - summary["mean_capture_risk_index"])
        + 0.16 * (1 - summary["mean_involution_pressure_index"])
    )
    summary["semantic_closure_score"] = round(closure_score, 4)
    summary["semantic_closure_grade"] = stability_grade(closure_score)
    summary["desire_prosperity_balance_index"] = round(clamp(
        0.30 * summary["mean_desire_quality_index"]
        + 0.28 * summary["mean_prosperity_contribution_index"]
        + 0.16 * summary["mean_capability_conversion_efficiency"]
        + 0.14 * (1 - summary["mean_involution_pressure_index"])
        + 0.12 * (1 - summary["mean_capture_risk_index"])
    ), 4)

    if summary["mean_involution_pressure_index"] >= 0.66 or summary["mean_capture_risk_index"] >= 0.66:
        overall = "structural_redesign_required"
    elif summary["desire_prosperity_balance_index"] >= 0.68 and closure_score >= 0.68:
        overall = "productive_desire_expansion_pilot"
    elif closure_score < 0.50:
        overall = "evidence_and_scope_closure_required"
    else:
        overall = "human_review_and_local_calibration_required"

    ledger = []
    tickets = []
    for idx, (item, score) in enumerate(zip(desires, desire_scores), start=1):
        ledger.append({
            "object_id": item.desire_id,
            "D": {"description": item.description, "intensity": item.intensity, "evidence_refs": item.evidence_refs or []},
            "I": {"category": item.category, "actor_type": item.actor_type, "three_no_signals": item.three_no_signals or []},
            "K": {
                "desire_quality_index": score["desire_quality_index"],
                "prosperity_contribution_index": score["prosperity_contribution_index"],
                "capability_conversion_efficiency": score["capability_conversion_efficiency"],
            },
            "W": {
                "capture_risk_index": score["capture_risk_index"],
                "time_sovereignty_index": score["time_sovereignty_index"],
                "ecological_externality": item.ecological_externality,
                "third_party_externality": item.third_party_externality,
            },
            "P": scenario.get("purpose_contract", {}),
            "R": {
                "evidence_strength": item.evidence_strength,
                "semantic_stability_score": score["semantic_stability_score"],
                "route": score["route"],
                "residual": "The score is a local deliberation proxy, not a diagnosis, eligibility decision, or moral rank.",
            },
        })
        tickets.append(action_ticket(item, score, idx))

    role = scenario.get("role", "individual")
    baseline = dict(summary)
    default_interventions = {
        "social_protection": 0.5,
        "public_services": 0.5,
        "kpi_reform": 0.5 if role in {"organization", "policy"} else 0.2,
        "anti_dark_pattern": 0.7 if role == "platform" else 0.2,
        "exit_rights": 0.6,
        "capability_vouchers": 0.6 if role in {"community", "policy", "household"} else 0.3,
    }
    simulation = simulate_interventions(baseline, default_interventions)

    return {
        "system": SYSTEM_NAME,
        "version": VERSION,
        "scenario_id": scenario.get("scenario_id", "unknown"),
        "name_zh": scenario.get("name_zh", "未命名场景"),
        "name_en": scenario.get("name_en", "Untitled scenario"),
        "role": role,
        "overall_decision": overall,
        "summary": summary,
        "purpose_contract": scenario.get("purpose_contract", {}),
        "desire_scores": desire_scores,
        "involution_scores": involution_scores,
        "dikwp_ledger": ledger,
        "action_tickets": tickets,
        "role_actions": ROLE_ACTIONS.get(role, ROLE_ACTIONS["individual"]),
        "default_policy_simulation": simulation,
        "residuals": [
            "Weights are configurable local policy parameters, not universal moral constants.",
            "Self-reported desires may differ from longitudinal behaviour and structural constraints.",
            "Distributional, labour, family, health, and ecological outcomes require external evaluation.",
            "The system cannot determine a person's worth, eligibility, employment, credit, welfare, or punishment.",
        ],
        "kill_conditions": [
            "Use for punitive social scoring, automatic eligibility denial, employment punishment, credit, insurance, policing, or surveillance.",
            "Hidden profiling, covert persuasion, or sale of inferred intentions without specific revocable consent.",
            "Removal of evidence, uncertainty, appeal, exit, or human review mechanisms.",
        ],
        "recovery_conditions": [
            "Return to voluntary, aggregate, reversible analysis.",
            "Restore purpose, evidence, residual, appeal, and exit ledgers.",
            "Recalibrate weights with affected stakeholders and publish distributional impacts.",
        ],
        "action_boundary": "Deliberation, education, workshop, voluntary self-reflection, organizational redesign, and reversible policy-pilot use only.",
    }


def load_scenarios(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if "scenarios" in data:
        return data["scenarios"]
    return [data]


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def render_markdown(report: dict[str, Any]) -> str:
    s = report["summary"]
    lines = [
        f"# {report['name_zh']}",
        "",
        f"- System: {report['system']} {report['version']}",
        f"- Scenario: `{report['scenario_id']}`",
        f"- Role: `{report['role']}`",
        f"- Decision: `{report['overall_decision']}`",
        f"- Semantic closure: **{s['semantic_closure_grade']}** ({s['semantic_closure_score']:.3f})",
        "",
        "## Core metrics",
        "",
        f"- Desire Quality Index: {s['mean_desire_quality_index']:.3f}",
        f"- Prosperity Contribution Index: {s['mean_prosperity_contribution_index']:.3f}",
        f"- Involution Pressure Index: {s['mean_involution_pressure_index']:.3f}",
        f"- Capture Risk Index: {s['mean_capture_risk_index']:.3f}",
        f"- Capability Conversion Efficiency: {s['mean_capability_conversion_efficiency']:.3f}",
        f"- Time Sovereignty Index: {s['mean_time_sovereignty_index']:.3f}",
        f"- Desire-Prosperity Balance Index: {s['desire_prosperity_balance_index']:.3f}",
        "",
        "## Action tickets",
        "",
    ]
    for ticket in report["action_tickets"]:
        lines += [
            f"### {ticket['ticket_id']} · {ticket['title']}",
            f"- Priority: {ticket['priority']}",
            f"- Owner: {ticket['owner']}",
            f"- Action: {ticket['action']}",
            f"- Rollback: {ticket['rollback_plan']}",
            "",
        ]
    lines += ["## Residuals", ""] + [f"- {x}" for x in report["residuals"]]
    lines += ["", "## Action boundary", "", report["action_boundary"], ""]
    return "\n".join(lines)


def export_report(report: dict[str, Any], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    write_json(out_dir / "desirebalance_report.json", report)
    write_json(out_dir / "dikwp_desire_ledger.json", report["dikwp_ledger"])
    write_json(out_dir / "action_tickets.json", report["action_tickets"])
    write_json(out_dir / "policy_simulation.json", report["default_policy_simulation"])
    write_csv(out_dir / "desire_scoreboard.csv", report["desire_scores"])
    write_csv(out_dir / "involution_contexts.csv", report["involution_scores"])
    write_csv(out_dir / "action_ticket_queue.csv", report["action_tickets"])
    (out_dir / "executive_summary.md").write_text(render_markdown(report), encoding="utf-8")


def static_audit(target: Path) -> dict[str, Any]:
    forbidden = [
        "subprocess", "os.system", "eval(", "exec(", "requests", "urllib.request", "socket", "selenium",
        "playwright", "puppeteer", "credential", "keylogger", "hidden telemetry", "automatic denial",
        "social credit", "punitive scoring",
    ]
    findings = []
    for path in target.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".py", ".js", ".html", ".md", ".json"}:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore").lower()
        except OSError:
            continue
        for token in forbidden:
            if token.lower() in text:
                # Allow boundary documentation and this audit list itself.
                if path.name in {"governance_boundary.md", "SECURITY.md", "static_audit.py", "desirebalance_cli.py"}:
                    continue
                findings.append({"file": str(path.relative_to(target)), "token": token})
    return {
        "system": SYSTEM_NAME,
        "version": VERSION,
        "policy": "No network clients, browser automation, subprocess execution, dynamic execution, credential capture, hidden telemetry, punitive social scoring, or automatic eligibility denial in the offline core.",
        "pass": not findings,
        "finding_count": len(findings),
        "findings": findings,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=SYSTEM_NAME)
    sub = parser.add_subparsers(dest="command")

    analyze_p = sub.add_parser("analyze", help="Analyse a scenario or scenario collection")
    analyze_p.add_argument("input", type=Path)
    analyze_p.add_argument("--scenario", help="Scenario ID when input contains a scenario collection")
    analyze_p.add_argument("--out", type=Path, default=Path("outputs/demo"))

    audit_p = sub.add_parser("static-audit", help="Audit the offline package boundary")
    audit_p.add_argument("target", type=Path, nargs="?", default=Path("."))
    audit_p.add_argument("--out", type=Path, default=Path("outputs/static_boundary_audit_report.json"))

    args = parser.parse_args()
    if args.command == "static-audit":
        result = static_audit(args.target)
        write_json(args.out, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["pass"] else 1

    if args.command != "analyze":
        parser.print_help()
        return 2

    scenarios = load_scenarios(args.input)
    if args.scenario:
        matches = [x for x in scenarios if x.get("scenario_id") == args.scenario]
        if not matches:
            print(f"Scenario not found: {args.scenario}", file=sys.stderr)
            return 2
        scenarios = matches

    if len(scenarios) == 1:
        report = analyze_scenario(scenarios[0])
        export_report(report, args.out)
        print(json.dumps({"scenario_id": report["scenario_id"], "decision": report["overall_decision"], "summary": report["summary"]}, ensure_ascii=False, indent=2))
    else:
        portfolio = []
        for scenario in scenarios:
            report = analyze_scenario(scenario)
            scenario_out = args.out / scenario["scenario_id"]
            export_report(report, scenario_out)
            portfolio.append({"scenario_id": report["scenario_id"], "name_zh": report["name_zh"], "role": report["role"], "decision": report["overall_decision"], **report["summary"]})
        write_json(args.out / "portfolio_summary.json", portfolio)
        write_csv(args.out / "portfolio_summary.csv", portfolio)
        print(json.dumps({"scenario_count": len(portfolio), "output": str(args.out)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
