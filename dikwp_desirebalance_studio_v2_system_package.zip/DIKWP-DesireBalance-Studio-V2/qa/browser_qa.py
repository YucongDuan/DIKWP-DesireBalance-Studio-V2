from pathlib import Path
from playwright.sync_api import sync_playwright
import json

root=Path(__file__).resolve().parents[1]
shots=root/'screenshots'
shots.mkdir(exist_ok=True)
html=(root/'index.html').read_text(encoding='utf-8')
console=[]
errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page(viewport={"width":1600,"height":1000}, device_scale_factor=1)
    page.on('console', lambda msg: console.append(f"{msg.type}: {msg.text}"))
    page.on('pageerror', lambda err: errors.append(str(err)))
    page.set_content(html, wait_until='load')
    page.wait_for_timeout(700)
    assert page.locator('#metricGrid .metric').count()==6
    assert page.locator('#dashboard').is_visible()
    page.screenshot(path=str(shots/'dashboard.png'), full_page=True)

    page.click('button[data-tab="portfolio"]')
    page.wait_for_timeout(250)
    assert page.locator('#portfolio tbody tr').count()>=3
    page.screenshot(path=str(shots/'portfolio.png'), full_page=True)

    page.click('button[data-tab="policy"]')
    page.wait_for_timeout(250)
    assert page.locator('#policy input[type="range"]').count()==6
    slider=page.locator('#policy input[data-intervention="kpi_reform"]')
    slider.fill('0.9')
    page.wait_for_timeout(250)
    page.screenshot(path=str(shots/'policy_lab.png'), full_page=True)

    page.click('button[data-tab="audit"]')
    page.wait_for_timeout(250)
    assert page.locator('#audit .export-card').count()==6
    page.screenshot(path=str(shots/'audit_export.png'), full_page=True)
    browser.close()

report={
  'render_mode':'playwright_page_set_content',
  'browser':'chromium',
  'viewport':'1600x1000',
  'screenshots':['dashboard.png','portfolio.png','policy_lab.png','audit_export.png'],
  'console':console,
  'page_errors':errors,
  'pass':not errors
}
(root/'qa'/'browser_qa_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
