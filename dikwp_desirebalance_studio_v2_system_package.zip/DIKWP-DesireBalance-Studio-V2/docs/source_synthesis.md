# Source Synthesis

This V2 studio follows the public design pattern visible in recent YucongDuan GitHub repositories: standalone, offline-first browser prototypes opened through `index.html`, with synthetic scenarios, optional CLI, schemas, documentation and exportable audit artifacts.

Primary conceptual sources in the earlier DIKWP project context include:

- DIKWP Data–Information–Knowledge–Wisdom–Purpose semantic organization
- DIKWP-Mesh 4.0 Three-No SemanticClosure
- semantic compression and intention coupling
- intention as goal, value, constraint, time and feedback
- evidence, residual, kill, recovery and action boundary separation

Current public repository reference:

- https://github.com/YucongDuan?tab=repositories
- https://github.com/YucongDuan/DIKWP-TRIZ-SemanticForge-Studio-V2
- https://github.com/YucongDuan/DIKWP-SemanticJustice-Studio-V2
- https://github.com/YucongDuan/DIKWP-HepatoScholar-Studio-V2
