# Ten-Minute Demonstration Script

## Minute 0–1: The contradiction

Ask: Should society release desire to create prosperity, or restrain desire to reduce involution? Explain that the system rejects the false binary and measures the conversion path.

## Minute 1–3: Dashboard

Open the organization scenario. Show DQI, PCI, IPI, capture risk, capability conversion and semantic closure. Emphasize that high AI tool usage does not automatically mean high capability.

## Minute 3–5: Live editing

Select “mandatory AI usage rate KPI.” Lower manipulation pressure and forced visibility. Show the route moving from cooling/review toward redesign.

## Minute 5–7: Three-No SemanticClosure

Explain incomplete evidence, imprecise benefit estimates and inconsistency between short-term conversion and long-term trust.

## Minute 7–9: Prosperity Conversion Lab

Raise KPI reform, exit rights and public services. Compare the projected change in prosperity, time sovereignty, involution and capture.

## Minute 9–10: Action Tickets

Export the action ticket queue and explain owner, evidence, rollback and kill conditions.
