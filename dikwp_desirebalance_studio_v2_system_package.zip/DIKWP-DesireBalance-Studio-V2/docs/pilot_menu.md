# Pilot Menu

## Enterprise Anti-Involution Diagnostic

- 2–4 weeks
- KPI and workflow mapping
- aggregate desire/cost ledger
- Action Ticket workshop
- no individual ranking

## Platform Intent and Dark-Pattern Review

- consent and intention architecture
- urgency and exit-friction audit
- long-term trust metrics

## Community Capability-Consumption Pilot

- health, care, education and culture services
- capability voucher simulation
- distributional and exit analysis

## Family and Education Workshop

- synthetic cases only in public demos
- capability portfolio and time-cost mapping
- not an admission or child assessment tool
