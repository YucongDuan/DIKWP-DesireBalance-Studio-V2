# Architecture

## Offline architecture

```text
Synthetic/User JSON
  -> Scenario Loader
  -> Desire Scoring Engine
  -> Competition Context Engine
  -> DIKWP Ledger Compiler
  -> 3-No SemanticClosure
  -> Intervention Simulator
  -> Role Playbook Router
  -> Action Ticket Generator
  -> Local Export
```

The browser studio is a single `index.html` file containing the interface, sample data and calculation logic. The CLI is a standard-library-only Python implementation for reproducible batch runs.

## Separation of layers

- **D**: explicit desire statements, evidence, intensity, costs.
- **I**: relations, categories, actors, competition context.
- **K**: scoring model, mechanism hypotheses, route selection.
- **W**: health, dignity, fairness, ecology, third-party cost, reversibility.
- **P**: goal, value, constraints, time window, feedback plan.
- **R**: evidence strength, residuals, stability, kill and recovery conditions.

## Non-goals

No production decision connector, network client, hidden telemetry, credentials, external account automation, or punitive decision workflow is included.
