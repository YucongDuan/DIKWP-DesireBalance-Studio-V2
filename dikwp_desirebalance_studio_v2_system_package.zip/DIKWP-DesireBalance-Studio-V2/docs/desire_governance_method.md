# Desire Governance Method

## The central distinction

The system does not divide desires into morally good and bad. It distinguishes whether a desire is converted into durable capability and shared prosperity, or amplified into positional competition, manipulation, debt, time loss and externalized cost.

## Core proxies

- DQI: Desire Quality Index
- PCI: Prosperity Contribution Index
- IPI: Involution Pressure Index
- CRI: Capture Risk Index
- DCCE: Desire-to-Capability Conversion Efficiency
- TSI: Time Sovereignty Index
- PCS: Purpose Coherence Score
- SCS: Semantic Closure Score

These are local, configurable deliberation proxies. They are not universal truths or eligibility scores.

## Three-No processing

- Incomplete: missing evidence, denominator, time, stakeholder, owner or feedback loop.
- Imprecise: vague benefit, uncertain probability, approximate scope or incomparable unit.
- Inconsistent: short-term and long-term objectives, actor benefits and cost bearers, or stated purpose and actual incentive conflict.

The system preserves residuals rather than forcing one answer.
