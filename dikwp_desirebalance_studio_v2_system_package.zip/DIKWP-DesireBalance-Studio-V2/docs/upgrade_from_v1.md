# Upgrade from V1

V1 delivered a CLI-oriented reference implementation and research outputs. V2 adds:

- a polished single-file browser studio
- direct double-click operation
- six role/scenario modes
- live parameter editing
- a policy and organizational intervention simulator
- DIKWP ledger visualization
- Three-No SemanticClosure visualization
- Action Ticket queue
- local import, snapshot and export
- presentation mode and ten-minute demo script
- expanded metrics and browser/CLI dual runproof
