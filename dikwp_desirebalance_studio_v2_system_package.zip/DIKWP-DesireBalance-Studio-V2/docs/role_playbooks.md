# Role Playbooks

## Individual

Use for voluntary self-reflection. Do not convert results into personal worth or employer decisions.

## Household

Make care time, debt, children's feedback and family resilience visible. Avoid single-score education decisions.

## Organization

Use aggregate and voluntary data. Do not rank individual workers. Reform KPIs and workload recovery mechanisms.

## Platform

Audit dark patterns, consent, intent reset and exit friction. Do not sell inferred intentions without specific revocable consent.

## Community and policy

Use reversible pilots, distributional analysis, public explanation, appeal and sunset clauses.
