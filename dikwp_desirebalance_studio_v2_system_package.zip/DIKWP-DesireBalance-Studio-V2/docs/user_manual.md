# User Manual

## Browser use

1. Open `index.html`.
2. Choose a scenario from the left panel.
3. Use the Dashboard for the one-minute overview.
4. In Desire Portfolio, click a row and adjust sliders.
5. Inspect the DIKWP Ledger and Three-No SemanticClosure.
6. In Prosperity Conversion Lab, adjust intervention intensities.
7. Export the report and Action Tickets.

## Custom scenario import

Use Audit and Export -> Import custom scenario. The input must follow `schemas/desirebalance_studio_case_schema_v2.json`.

## Local snapshot

The Save Local button stores the currently edited scenario in browser local storage. No server is used.

## CLI use

```bash
python cli/desirebalance_cli.py analyze examples/organization_kpi_involution.json --out outputs/org
```
