# Governance Boundary

## Allowed

- education and public discussion
- voluntary personal or family reflection
- aggregate organizational workshops
- platform design review
- reversible community and policy pilots
- research hypothesis formation

## Prohibited

- social credit or punitive ranking
- automatic welfare or benefit denial
- employment, promotion, dismissal or compensation decisions
- credit, insurance, policing, immigration or admission decisions
- covert intention profiling or manipulation
- selling inferred intentions without specific revocable consent
- moral ranking of people or groups
- replacing qualified legal, labour, clinical or policy professionals
