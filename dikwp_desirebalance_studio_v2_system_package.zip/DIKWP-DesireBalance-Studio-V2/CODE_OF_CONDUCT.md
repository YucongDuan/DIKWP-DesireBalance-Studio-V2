# Code of Conduct

This project welcomes respectful, evidence-oriented collaboration. Do not use the project to stigmatize people, moralize poverty, punish dissent, manipulate vulnerable users, or convert structural risks into personal blame.
